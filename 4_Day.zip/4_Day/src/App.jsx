import ApiCall from "./ApiCall";
import Todo from "./Todo";

function App() {
 function getdata(data){
   console.log(data);
 }

  return (
    <>
    <Todo/>
    </>
  )
}

export default App