import {configureStore} from '@reduxjs/toolkit'
const store = configureStore({
    reducer : null
})
export default store;